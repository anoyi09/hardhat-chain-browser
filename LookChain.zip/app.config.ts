export default {
  RpcUrl: 'http://127.0.0.1:8545/',
  hardHatProjectPath: 'E:/OpenProjects/hardhatTest1/'
}
