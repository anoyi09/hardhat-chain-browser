

<template>
    <div>
        <BaseQuery v-loading="bLoading" :tableData="eventsLogs" :showPagination="false" :columns="columns">
            <template v-slot:topButton>
                <div style="margin-top:26px">
                    <el-button @click="handleRefresh">刷新</el-button>
                </div>
            </template>
        </BaseQuery>
    </div>
</template>
  
<script setup lang="ts">
import { ref } from 'vue'
import { dateFormat } from "@/utils/index"
import { useEventsLogsStore } from "@/stores/eventLogs"
import { storeToRefs } from 'pinia'
const columns = [
    { label: 'Index', prop: 'index', type: 'index', width: 80 },
    { label: 'name', prop: 'name', width: 90 },
    { label: 'eventName', prop: 'eventName', width: 120 },
    { label: 'timestamp', prop: 'timestamp', width: 180, formatter: (row: Record<string, any>) => `${dateFormat(row.timestamp)}` },
    { label: 'contractAddress', prop: 'contractAddress', width: 380 },
    { label: 'msg', prop: 'msg' }
]
const store = useEventsLogsStore()
const { eventsLogs } = storeToRefs(store)
const bLoading = ref(false)
const handleRefresh = () => {
    bLoading.value = true
    setTimeout(async () => {
        store.setEventsLogs([])
        await store.initEventsLogs(true)
        bLoading.value = false
    }, 300)

}

</script>
  