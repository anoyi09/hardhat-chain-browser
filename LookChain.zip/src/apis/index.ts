import * as Accounts from './Accounts'
import * as Blocks from './Blocks'
import * as Contract from './Contract'

export default { Accounts, Blocks, Contract }
