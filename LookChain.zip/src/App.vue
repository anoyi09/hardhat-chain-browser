

<template>
  <LayOut></LayOut>
</template>
<script setup lang="ts">
// import LayOut from '@/components/LayOut.vue'
</script>
